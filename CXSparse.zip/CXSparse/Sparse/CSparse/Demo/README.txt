CSparse/Demo:  to compile a run the demos, just type "make" in this directory.
The printed residuals should all be small, except for the mbeacxc matrix
(which is numerically and structurally singular), and ash219 (which is a
least-squares problem).  See cs_demo.out for the proper output of "make".

Timothy A. Davis, http://www.suitesparse.com
